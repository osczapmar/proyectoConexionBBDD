package basedatospersonaje;

/**
 *
 * @author santi
 */
public abstract class ORMEntity {
    
    public ORMEntity()
    {
        super();
    }
}
